package com.example.lab_week_05

class Coffee {
    val title:String = ""
}